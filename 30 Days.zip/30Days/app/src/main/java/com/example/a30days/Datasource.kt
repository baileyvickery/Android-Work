package com.example.a30days

/**
 * [Datasource] generates a list of [Days]
 */
class Datasource() {
    fun loadDays(): List<Days> {
        return listOf<Days>(
            Days(R.string.one,R.string.day1, R.drawable.spaghetti),
            Days(R.string.two,R.string.day2,R.drawable.cheese_burger),
            Days(R.string.three,R.string.day3,R.drawable.chicken_parm),
            Days(R.string.four,R.string.day4,R.drawable.jambalaya),
            Days(R.string.five,R.string.day5 ,R.drawable.herb ),
            Days(R.string.six,R.string.day6 ,R.drawable.pizza),
            Days(R.string.seven,R.string.day7 ,R.drawable.ice_cream ),
            Days(R.string.eight,R.string.day8 ,R.drawable.chili ),
            Days(R.string.nine,R.string.day9 ,R.drawable.white_chicken ),
            Days(R.string.ten,R.string.day10 ,R.drawable.enchillada ),
            Days(R.string.eleven,R.string.day11 ,R.drawable.bowl ),
            Days(R.string.twelve,R.string.day12 ,R.drawable.hibachi ),
            Days(R.string.thirteen,R.string.day13 ,R.drawable.squash),
            Days(R.string.fourteen,R.string.day14 ,R.drawable.lasagna ),
            Days(R.string.fifteen,R.string.day15 ,R.drawable.taco ),
            Days(R.string.sixteen,R.string.day16 ,R.drawable.alfredo ),
            Days(R.string.seventeen,R.string.day17 ,R.drawable.feta ),
            Days(R.string.eighteen,R.string.day18 ,R.drawable.steak_burrito ),
            Days(R.string.nineteen,R.string.day19 ,R.drawable.potatoes ),
            Days(R.string.twenty,R.string.day20 ,R.drawable.veggie ),
            Days(R.string.twentyone,R.string.day21 ,R.drawable.grill ),
            Days(R.string.twentytwo,R.string.day22 ,R.drawable.pot_pie ),
            Days(R.string.twentythree,R.string.day23 ,R.drawable.orange ),
            Days(R.string.twentyfour,R.string.day24 ,R.drawable.roast ),
            Days(R.string.twentyfive,R.string.day25 ,R.drawable.philly ),
            Days(R.string.twentysix,R.string.day26 ,R.drawable.wrap ),
            Days(R.string.twentyseven,R.string.day27 ,R.drawable.slidder ),
            Days(R.string.twentyeight,R.string.day28 ,R.drawable.cake ),
            Days(R.string.twentynine,R.string.day29 ,R.drawable.egg ),
            Days(R.string.thirty,R.string.day30 ,R.drawable.breakfast ),
        )
    }
}
