package com.example.a30days

import androidx.annotation.DrawableRes
import androidx.annotation.StringRes

data class Days(
    @StringRes val stringResId: Int,
    @StringRes val stringResourceId: Int,
    @DrawableRes val imageResourceId: Int
)
