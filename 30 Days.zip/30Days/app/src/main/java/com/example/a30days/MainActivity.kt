package com.example.a30days

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.a30days.ui.theme._30DaysTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            _30DaysTheme {
                // A surface container using the 'background' color from the theme
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    DaysApp()
                }
            }
        }
    }
}

@Composable
fun DaysApp(){
    DaysList (
        DaysList = Datasource().loadDays()
    )
}

@Composable
fun DaysCard(day: Days, modifier: Modifier = Modifier){
    var expanded by remember { mutableStateOf(false) };
    Card(modifier = modifier
        .animateContentSize()
        .height(if (expanded) 300.dp else 200.dp)
        .fillMaxWidth()
        .clickable(
            interactionSource = remember { MutableInteractionSource() },
            indication = null
        ) {
            expanded = !expanded
        }){
        Column {
            Text(
                text = LocalContext.current.getString(day.stringResId),
                modifier = Modifier,
                style = MaterialTheme.typography.headlineSmall
            )
            Image (
                painter = painterResource(day.imageResourceId),
                contentDescription = stringResource(day.stringResourceId),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(200.dp)
                    .padding(20.dp)
                    .clip(MaterialTheme.shapes.small),
                contentScale = ContentScale.Crop

            )
            Text(
                text = LocalContext.current.getString(day.stringResourceId),
                modifier = Modifier,
                style = MaterialTheme.typography.headlineSmall
            )
        }
    }
}


@Composable
fun DaysList (DaysList: List<Days>, modifier: Modifier = Modifier){
    Scaffold(
        topBar = {
            DayTopBar()
        }
    ) { it ->
        LazyColumn(contentPadding = it) {
            items(DaysList) { day ->
                DaysCard(
                    day = day,
                    modifier = Modifier.padding(8.dp)
                )

            }
        }
    }

}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DayTopBar(modifier: Modifier = Modifier){
    CenterAlignedTopAppBar(
        title = {
            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {

            Text(
                text = "30 Days of Recipes"
                )
            }
        },
        modifier = modifier
    )
}

@Preview
@Composable
private fun DaysAppPreview (){
    DaysCard(Days(R.string.one,R.string.day1, R.drawable.spaghetti))
}